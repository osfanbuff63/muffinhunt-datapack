`Warning! This page has a lot of info about MuffinHunts! If you want a shorter variant, check out the` [README](README.md)

# What is a MuffinHunt?

## General overview of the series
MuffinHunt is a variation of a certain YouTuber's series, Speedrunner VS Hunter(s). However, MuffinHunt has many changes and tweaks from the remarkably simple Speedrunner VS Hunter.
In a MuffinHunt, the Dragon Ender (formerly known as Speedrunner) is attempting to beat the Ender Dragon (its namesake) before the Juggernaut (formerly known as Hunter) can defeat them.

### Dragon Ender info
The Dragon Ender is trying to get as many resources as they can in a short span of time. They start with a Chainmail Chestplate, a netherite pickaxe, and a shield. (And of course food. :P
Their goal is to defeat the Ender Dragon before the Juggernaut can kill them.

### Juggernaut info
The Juggernaut's primary goal is to defeat the Dragon Ender. Their gear upgrades automatically over time. One of the best strategies to use as a Juggernaut is to try to sabotage the Dragon Ender as much as possible.

## More specific details
Once the Dragon Ender leaves the Overworld for the Nether, everyone is given their Nether upgrades. The Dragon Ender must locate both a Blaze spawner and Enderman spawner.
These are placed before the MuffinHunt begins. Both the Juggernaut and Dragon Ender can use this.

When the Dragon Ender has had enough of the firey Nether, they can come back to the Overworld and will arrive on the surface. Located here are some villagers, trading for 
bows and arrows. 

If the Dragon Ender survives this long, they can find their way back down to the end portal, where they will enter the End.

The End is arguably the most chaotic part of this. As the Dragon Ender attempts to destroy the Ender Dragon, while the Juggernaut is trying to take their last oppertunity to destroy them, can be very fun and chaotic.   
